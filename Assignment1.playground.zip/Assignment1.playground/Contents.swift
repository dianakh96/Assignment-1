import UIKit

var greeting = "Hello, playground"
//-----------------------------------------------------------------
//ASSIGNMENT DAY 1
//Array vs Reverse array:

var input = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print("Array: \(input)")
input.reverse()
print("Inverse Array: \(input)")

// Prime number finder :

var primeNumber = [Int]()

for number in input {
    if (number % 2 == 0 || number % 3 == 0 || number % 4 == 0 || number % 5 == 0 || number % 6 == 0) || number % 7 == 0 || number % 8 == 0 || number % 9 == 0 {
        print("Its not a prime number")
    } else {
        primeNumber.append(number)
    }
}

print(primeNumber)

//Even odd finder

for n in input{
    if(n % 2 == 0){
        print("\(n) is even")
    }else{
        print("\(n) is odd")
    }
}

// Factorial for a given number:

func factorial(n: Int) -> Int {
    var result = 1
    if(n > 0) {
        for i in 1...n {
            result *= i
        }
    }
    return result
}
 
let num = 5
let result = factorial(n: num)
print("the prime of \(num)! = \(result)")
